package com.chesscoach

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File

class EngineResult(val move: String, val score: String, val depth: Int)

class Engine(private val ctx: Context) {
    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private var reader: BufferedReader? = null

    @Volatile
    var ready = false

    private fun send(s: String) {
        val w = writer ?: return
        w.write(s)
        w.write("\n")
        w.flush()
    }

    private fun waitFor(token: String) {
        val r = reader ?: return
        while (true) {
            val line = r.readLine() ?: return
            if (line.startsWith(token)) return
        }
    }

    fun start(): Boolean {
        try {
            val path = ctx.applicationInfo.nativeLibraryDir + "/libstockfish.so"
            val f = File(path)
            if (!f.exists()) return false
            val pb = ProcessBuilder(path)
            pb.redirectErrorStream(true)
            val p = pb.start()
            proc = p
            writer = p.outputStream.bufferedWriter()
            reader = p.inputStream.bufferedReader()
            send("uci")
            waitFor("uciok")
            val cores = Runtime.getRuntime().availableProcessors()
            val threads = (cores - 2).coerceIn(2, 4)
            send("setoption name Threads value $threads")
            send("setoption name Hash value 64")
            send("isready")
            waitFor("readyok")
            ready = true
            return true
        } catch (e: Exception) {
            return false
        }
    }

    @Synchronized
    fun newGame() {
        if (!ready) return
        try {
            send("ucinewgame")
            send("isready")
            waitFor("readyok")
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun bestMove(fen: String, moveTimeMs: Int): EngineResult? {
        if (!ready) return null
        try {
            send("position fen $fen")
            send("go movetime $moveTimeMs")
            var depth = 0
            var score = ""
            val r = reader ?: return null
            while (true) {
                val line = r.readLine() ?: return null
                if (line.startsWith("info") && line.contains(" pv ")) {
                    val t = line.split(" ")
                    val di = t.indexOf("depth")
                    if (di >= 0 && di + 1 < t.size) depth = t[di + 1].toIntOrNull() ?: depth
                    val si = t.indexOf("score")
                    if (si >= 0 && si + 2 < t.size) {
                        score = if (t[si + 1] == "cp") {
                            val cp = (t[si + 2].toIntOrNull() ?: 0) / 100.0
                            String.format("%+.2f", cp)
                        } else {
                            "M" + t[si + 2]
                        }
                    }
                } else if (line.startsWith("bestmove")) {
                    val p = line.split(" ")
                    if (p.size > 1 && p[1] != "(none)" && p[1] != "0000") {
                        return EngineResult(p[1], score, depth)
                    }
                    return null
                }
            }
        } catch (e: Exception) {
            return null
        }
    }

    fun destroy() {
        try {
            send("quit")
        } catch (e: Exception) {
        }
        try {
            proc?.destroy()
        } catch (e: Exception) {
        }
        ready = false
    }
}
