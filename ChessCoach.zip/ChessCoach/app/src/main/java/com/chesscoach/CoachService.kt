package com.chesscoach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class CoachService : Service() {
    companion object {
        const val CH_ID = "coach"
        val SPEEDS = intArrayOf(150, 350, 900)
        val SPEED_NAMES = arrayOf("سریع", "متوسط", "قوی")
        const val ALPHA = 150
        const val COLOR_FROM = 0x2979FF
        const val COLOR_TO = 0x00C853
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())
    private var capThread: HandlerThread? = null
    private lateinit var ch: Handler
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val br = BoardReader()
    private lateinit var engine: Engine
    private val execEngine = Executors.newSingleThreadExecutor()

    private var sw = 0
    private var sh = 0
    private var started = false

    // views (main thread)
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var statusView: TextView? = null
    private var colorBtn: TextView? = null
    private var speedBtn: TextView? = null
    private var circleView: CircleView? = null
    private var calib: CalibLayout? = null

    // state (cap thread)
    @Volatile private var rect: RectF? = null
    @Volatile private var circlesNow: List<Circle> = emptyList()
    private var userWhite = true
    private var speedIdx = 1
    private var tpl: Templates? = null
    private var running = false
    private var loadedOnce = false
    private var accepted: IntArray? = null
    private var cand: IntArray? = null
    private var candSince = 0L
    private var handled: IntArray? = null
    private var side = 0
    private val rights = BooleanArray(4)
    private var ep = -1
    private var token = 0
    @Volatile private var dumpRequested = false

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_NOT_STICKY
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_ID, "Chess Coach", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CH_ID)
            .setContentTitle("Chess Coach")
            .setContentText("در حال اجرا")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        started = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("coach", Context.MODE_PRIVATE)
        userWhite = prefs.getBoolean("white", true)
        speedIdx = prefs.getInt("speed", 1).coerceIn(0, 2)
        engine = Engine(this)
        capThread = HandlerThread("cap").also { it.start() }
        ch = Handler(capThread!!.looper)
        try {
            setupCapture(code, data)
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در ضبط صفحه: " + e.message, Toast.LENGTH_LONG).show()
            shutdown()
            return START_NOT_STICKY
        }
        rect = loadRect()
        buildOverlays()
        status("در حال آماده‌سازی موتور…", Color.WHITE)
        execEngine.execute {
            val ok = engine.start()
            status(
                if (ok) "آماده. رنگ را انتخاب کن، کالیبره کن، شروع بزن"
                else "خطا: موتور شطرنج اجرا نشد",
                if (ok) Color.WHITE else Color.RED
            )
        }
        ch.postDelayed(tick, 200)
        return START_NOT_STICKY
    }

    private fun setupCapture(code: Int, data: Intent) {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels
        sh = dm.heightPixels
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                ui.post { shutdown() }
            }
        }, ui)
        val rd = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = rd
        vd = mp.createVirtualDisplay(
            "cc", sw, sh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
        )
    }

    // ---------------- rect ----------------
    private fun defaultRect(): RectF {
        val sx = sw / 1080f
        val sy = sh / 2340f
        return RectF(32f * sx, 634f * sy, 1048f * sx, 1652f * sy)
    }

    private fun loadRect(): RectF {
        if (prefs.contains("rl")) {
            return RectF(
                prefs.getFloat("rl", 0f), prefs.getFloat("rt", 0f),
                prefs.getFloat("rr", 0f), prefs.getFloat("rb", 0f)
            )
        }
        return defaultRect()
    }

    private fun saveRect(r: RectF) {
        prefs.edit().putFloat("rl", r.left).putFloat("rt", r.top)
            .putFloat("rr", r.right).putFloat("rb", r.bottom).apply()
    }

    // ---------------- UI ----------------
    private fun status(msg: String, color: Int = Color.WHITE) {
        ui.post {
            statusView?.text = msg
            statusView?.setTextColor(color)
        }
    }

    private fun mkButton(label: String, bg: Int, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(8), dp(10), dp(8))
        val g = GradientDrawable()
        g.setColor(bg)
        g.cornerRadius = dp(8).toFloat()
        t.background = g
        t.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        t.layoutParams = lp
        return t
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun fullLp(touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(sw, sh, overlayType(), flags, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun buildOverlays() {
        val cv = CircleView(this)
        circleView = cv
        wm.addView(cv, fullLp(false))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xE6101820.toInt())
        bg.cornerRadius = dp(12).toFloat()
        root.background = bg
        root.setPadding(dp(6), dp(6), dp(6), dp(6))

        val st = TextView(this)
        st.setTextColor(Color.WHITE)
        st.textSize = 13f
        st.maxWidth = dp(300)
        st.setPadding(dp(4), dp(2), dp(4), dp(4))
        st.text = "Chess Coach"
        statusView = st
        root.addView(st)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL

        val cb = mkButton(if (userWhite) "من: سفید" else "من: سیاه", 0xFF455A64.toInt()) {
            userWhite = !userWhite
            prefs.edit().putBoolean("white", userWhite).apply()
            colorBtn?.text = if (userWhite) "من: سفید" else "من: سیاه"
            ch.post { resetRun() }
        }
        colorBtn = cb
        row1.addView(cb)
        row1.addView(mkButton("کالیبره", 0xFF6A1B9A.toInt()) { openCalib() })
        row1.addView(mkButton("شروع", 0xFF2E7D32.toInt()) { ch.post { doStart() } })

        row2.addView(mkButton("نوبت من", 0xFF1565C0.toInt()) { ch.post { forceMyTurn() } })
        val sb = mkButton("سرعت: " + SPEED_NAMES[speedIdx], 0xFFEF6C00.toInt()) {
            speedIdx = (speedIdx + 1) % 3
            prefs.edit().putInt("speed", speedIdx).apply()
            speedBtn?.text = "سرعت: " + SPEED_NAMES[speedIdx]
        }
        speedBtn = sb
        row2.addView(sb)
        row2.addView(mkButton("دیباگ", 0xFF00695C.toInt()) {
            dumpRequested = true
            status("تصویر دیباگ در حال ذخیره…")
        })
        row2.addView(mkButton("خروج", 0xFFC62828.toInt()) { shutdown() })
        root.addView(row1)
        root.addView(row2)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(24)
        panelLp = lp
        panel = root

        var dx = 0f
        var dy = 0f
        var px = 0
        var py = 0
        st.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX
                    dy = e.rawY
                    px = lp.x
                    py = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = px + (e.rawX - dx).toInt()
                    lp.y = py + (e.rawY - dy).toInt()
                    try {
                        wm.updateViewLayout(root, lp)
                    } catch (ex: Exception) {
                    }
                }
            }
            true
        }
        wm.addView(root, lp)
    }

    private fun openCalib() {
        if (calib != null) return
        val r = rect ?: defaultRect()
        val cl = CalibLayout(this, RectF(r)) { nr ->
            rect = RectF(nr)
            saveRect(nr)
            closeCalib()
            ch.post { resetRun() }
            status("کادر ذخیره شد. حالا «شروع»", Color.WHITE)
        }
        calib = cl
        wm.addView(cl, fullLp(true))
        // keep the panel above the calibration layer
        panel?.let {
            try {
                wm.removeView(it)
                wm.addView(it, panelLp!!)
            } catch (e: Exception) {
            }
        }
    }

    private fun closeCalib() {
        calib?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        calib = null
    }

    private fun setCircles(list: List<Circle>) {
        circlesNow = list
        ui.post {
            circleView?.circles = list
            circleView?.invalidate()
        }
    }

    // ---------------- capture loop ----------------
    private val tick = object : Runnable {
        override fun run() {
            try {
                doTick()
            } catch (e: Throwable) {
                Log.e("ChessCoach", "tick", e)
            }
            if (started) ch.postDelayed(this, 60)
        }
    }

    private fun dumpDebug(f: Frame, rc: RectF) {
        try {
            val l = rc.left.toInt()
            val t = rc.top.toInt()
            val w = (rc.right - rc.left).toInt()
            val h = (rc.bottom - rc.top).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    bmp.setPixel(x, y, 0xFF000000.toInt() or f.rgb(l + x, t + y))
                }
            }
            val cv = Canvas(bmp)
            val pl = Paint()
            pl.color = 0xFFFFEB3B.toInt()
            pl.strokeWidth = 2f
            val pt = Paint(Paint.ANTI_ALIAS_FLAG)
            pt.color = 0xFFFF1744.toInt()
            pt.textSize = 34f
            val pm = Paint()
            pm.color = 0x5500E5FF
            val sqw = w / 8f
            val sqh = h / 8f
            for (r in 0..7) {
                for (c in 0..7) {
                    val m = br.maskAt(r, c)
                    val g = BoardReader.G
                    for (j in 0 until g) {
                        for (i in 0 until g) {
                            if (m[j * g + i]) {
                                val x0 = c * sqw + i * sqw / g
                                val y0 = r * sqh + j * sqh / g
                                cv.drawRect(x0, y0, x0 + sqw / g, y0 + sqh / g, pm)
                            }
                        }
                    }
                    cv.drawText((if (br.occAt(r, c)) "X" else "-") + br.massAt(r, c), c * sqw + 6f, r * sqh + 36f, pt)
                }
            }
            for (i in 0..8) {
                cv.drawLine(i * sqw, 0f, i * sqw, h.toFloat(), pl)
                cv.drawLine(0f, i * sqh, w.toFloat(), i * sqh, pl)
            }
            val info = "frame " + f.w + "x" + f.h + " screen " + sw + "x" + sh + " rect " + rc.left.toInt() + "," + rc.top.toInt() + "," + rc.right.toInt() + "," + rc.bottom.toInt()
            cv.drawText(info, 10f, h - 12f, pt)
            val values = ContentValues()
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "chess_debug_" + System.currentTimeMillis() + ".png")
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ChessCoach")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                status("تصویر دیباگ ذخیره شد: گالری ← Pictures/ChessCoach", Color.GREEN)
            } else {
                status("ذخیره تصویر دیباگ ممکن نشد", Color.RED)
            }
        } catch (e: Exception) {
            status("خطا در دیباگ: " + e.message, Color.RED)
        }
    }

    private fun doTick() {
        val rd = reader ?: return
        val img = rd.acquireLatestImage()
        val now = SystemClock.uptimeMillis()
        if (img != null) {
            try {
                val rc = rect
                if (rc != null) {
                    val p = img.planes[0]
                    val f = Frame(p.buffer, img.width, img.height, p.rowStride, p.pixelStride)
                    br.load(f, rc.left, rc.top, rc.right, rc.bottom, circlesNow)
                    loadedOnce = true
                    if (dumpRequested) {
                        dumpRequested = false
                        dumpDebug(f, rc)
                    }
                    val t = tpl
                    if (running && t != null) {
                        val res = br.parse(userWhite, t, accepted)
                        if (!res.ok || !validBoard(res.board)) {
                            cand = null
                        } else {
                            val c = cand
                            if (c == null || !c.contentEquals(res.board)) {
                                cand = res.board
                                candSince = now
                            }
                        }
                    }
                }
            } finally {
                img.close()
            }
        }
        if (running) evaluate(now)
    }

    // ---------------- game logic ----------------
    private fun myColor(): Int = if (userWhite) 1 else -1

    private fun resetRun() {
        running = false
        accepted = null
        cand = null
        handled = null
        side = 0
        token++
        setCircles(emptyList())
        status("آماده — «شروع» را بزن")
    }

    private fun doStart() {
        if (rect == null) {
            status("اول کادر را کالیبره کن", Color.YELLOW)
            return
        }
        if (!loadedOnce) {
            status("هنوز تصویری نگرفته‌ام؛ چند ثانیه صبر کن", Color.YELLOW)
            return
        }
        if (!engine.ready) {
            status("موتور هنوز آماده نیست", Color.YELLOW)
            return
        }
        if (panelOverlapsBoard()) {
            status("پنل روی صفحه شطرنج بود؛ بالا بردمش. دوباره «شروع» بزن", Color.YELLOW)
            return
        }
        setCircles(emptyList())
        val dc = br.detectColor()
        if (dc != 0 && (dc == 1) != userWhite) {
            userWhite = dc == 1
            prefs.edit().putBoolean("white", userWhite).apply()
            ui.post { colorBtn?.text = if (userWhite) "من: سفید" else "من: سیاه" }
        }
        val learned = br.learn(userWhite)
        if (learned != null) {
            val test = br.parse(userWhite, learned, null)
            if (!test.ok || !test.board.contentEquals(BoardReader.initialBoard())) {
                val init = BoardReader.initialBoard()
                val bad = StringBuilder()
                for (i in 0 until 64) {
                    if (test.board[i] != init[i]) bad.append(('a' + (i % 8))).append('1' + (i / 8)).append(' ')
                }
                status("یادگیری ناموفق. خانه‌های اشتباه: " + bad + " ok=" + test.ok, Color.RED)
                return
            }
            tpl = learned
            prefs.edit().putString(if (userWhite) "tpl_w" else "tpl_b", BoardReader.encode(learned)).apply()
            running = true
            newGame(test.board)
            return
        }
        val saved = prefs.getString(if (userWhite) "tpl_w" else "tpl_b", "") ?: ""
        val t = BoardReader.decode(saved)
        if (t == null) {
            status("تشخیص مهره‌ها ناموفق. تعداد مهره هر ردیف (از بالا): " + br.debug(), Color.YELLOW)
            return
        }
        tpl = t
        val res = br.parse(userWhite, t, null)
        if (!res.ok || !validBoard(res.board)) {
            status("تشخیص صفحه ناموفق؛ کالیبراسیون یا رنگ را چک کن", Color.RED)
            return
        }
        running = true
        accepted = res.board
        cand = res.board
        handled = res.board
        side = 0
        ep = -1
        java.util.Arrays.fill(rights, false)
        token++
        status("وسط بازی شروع شد. نوبت توست؟ «نوبت من» را بزن، وگرنه منتظر حرکت حریف می‌مانم")
    }

    /** The panel is part of the screen capture, so it must not sit on top of the board. */
    private fun panelOverlapsBoard(): Boolean {
        val rc = rect ?: return false
        val p = panel ?: return false
        val lp = panelLp ?: return false
        val pr = RectF(lp.x.toFloat(), lp.y.toFloat(), (lp.x + p.width).toFloat(), (lp.y + p.height).toFloat())
        if (!RectF.intersects(pr, rc)) return false
        ui.post {
            lp.y = Math.max(0, (rc.top - p.height - dp(8)).toInt())
            try {
                wm.updateViewLayout(p, lp)
            } catch (e: Exception) {
            }
        }
        return true
    }

    private fun forceMyTurn() {
        if (!running || accepted == null) {
            status("اول «شروع» را بزن", Color.YELLOW)
            return
        }
        side = myColor()
        analyze()
    }

    private fun newGame(b: IntArray) {
        accepted = b
        cand = b
        handled = b
        ep = -1
        java.util.Arrays.fill(rights, true)
        side = 1
        token++
        execEngine.execute { engine.newGame() }
        setCircles(emptyList())
        if (userWhite) analyze() else status("بازی شروع شد؛ منتظر حرکت حریف…")
    }

    private fun validBoard(b: IntArray): Boolean {
        var wk = 0
        var bk = 0
        var wp = 0
        var bp = 0
        var wt = 0
        var bt = 0
        for (i in 0 until 64) {
            val v = b[i]
            if (v == 0) continue
            if (v > 0) {
                wt++
                if (v == 6) wk++
                if (v == 1) {
                    wp++
                    if (i < 8 || i >= 56) return false
                }
            } else {
                bt++
                if (v == -6) bk++
                if (v == -1) {
                    bp++
                    if (i < 8 || i >= 56) return false
                }
            }
        }
        return wk == 1 && bk == 1 && wt <= 16 && bt <= 16 && wp <= 8 && bp <= 8
    }

    private fun updateRights(b: IntArray) {
        if (b[4] != 6) {
            rights[0] = false
            rights[1] = false
        }
        if (b[7] != 4) rights[0] = false
        if (b[0] != 4) rights[1] = false
        if (b[60] != -6) {
            rights[2] = false
            rights[3] = false
        }
        if (b[63] != -4) rights[2] = false
        if (b[56] != -4) rights[3] = false
    }

    private fun evaluate(now: Long) {
        val c = cand ?: return
        if (now - candSince < 110) return
        val h = handled
        if (h != null && h.contentEquals(c)) return
        handled = c
        val acc = accepted
        if (acc == null) {
            accepted = c
            return
        }
        val changed = ArrayList<Int>()
        for (i in 0 until 64) if (acc[i] != c[i]) changed.add(i)
        if (changed.isEmpty()) return

        if (c.contentEquals(BoardReader.initialBoard())) {
            newGame(c)
            return
        }
        if (changed.size > 4) {
            accepted = c
            side = 0
            ep = -1
            updateRights(c)
            token++
            setCircles(emptyList())
            status("صفحه تغییر زیادی کرد؛ همگام شدم. اگر نوبت توست «نوبت من» را بزن", Color.YELLOW)
            return
        }
        var mover = 0
        var mixed = false
        for (i in changed) {
            if (c[i] != 0) {
                val m = if (c[i] > 0) 1 else -1
                if (mover == 0) mover = m else if (mover != m) mixed = true
            }
        }
        if (mover == 0) return
        if (mixed) {
            accepted = c
            side = 0
            token++
            return
        }
        // en passant square for double pawn pushes
        ep = -1
        for (d in changed) {
            if (c[d] == mover && acc[d] == 0) {
                for (o in changed) {
                    if (acc[o] == mover && c[o] == 0 && o % 8 == d % 8 && Math.abs(o / 8 - d / 8) == 2) {
                        ep = (o + d) / 2
                    }
                }
            }
        }
        updateRights(c)
        accepted = c
        side = -mover
        token++
        if (side == myColor()) {
            analyze()
        } else {
            setCircles(emptyList())
            status("نوبت حریف…")
        }
    }

    private fun buildFen(b: IntArray, stm: Int): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val v = b[rank * 8 + file]
                if (v == 0) {
                    empty++
                } else {
                    if (empty > 0) {
                        sb.append(empty)
                        empty = 0
                    }
                    val pc = "pnbrqk"[Math.abs(v) - 1]
                    sb.append(if (v > 0) pc.uppercaseChar() else pc)
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(if (stm > 0) " w " else " b ")
        var cs = ""
        if (rights[0]) cs += "K"
        if (rights[1]) cs += "Q"
        if (rights[2]) cs += "k"
        if (rights[3]) cs += "q"
        sb.append(if (cs.isEmpty()) "-" else cs)
        sb.append(' ')
        if (ep >= 0) {
            sb.append('a' + (ep % 8))
            sb.append('1' + (ep / 8))
        } else {
            sb.append('-')
        }
        sb.append(" 0 1")
        return sb.toString()
    }

    private fun analyze() {
        val b = accepted ?: return
        val fen = buildFen(b, side)
        token++
        val myToken = token
        val ms = SPEEDS[speedIdx]
        status("در حال تحلیل…")
        execEngine.execute {
            val r = engine.bestMove(fen, ms)
            ch.post { if (myToken == token) showResult(r) }
        }
    }

    private fun showResult(r: EngineResult?) {
        val rc = rect ?: return
        if (r == null || r.move.length < 4) {
            status("حرکتی پیدا نشد (تشخیص صفحه ممکن است اشتباه باشد)", Color.RED)
            return
        }
        val m = r.move
        val from = (m[1] - '1') * 8 + (m[0] - 'a')
        val to = (m[3] - '1') * 8 + (m[2] - 'a')
        if (from !in 0..63 || to !in 0..63) return
        val cw = (rc.right - rc.left) / 8f
        val chh = (rc.bottom - rc.top) / 8f
        val rad = Math.min(cw, chh) / 2f - 1f
        fun mk(sq: Int, color: Int): Circle {
            val rr = BoardReader.screenRow(sq, userWhite)
            val cc = BoardReader.screenCol(sq, userWhite)
            return Circle(rc.left + (cc + 0.5f) * cw, rc.top + (rr + 0.5f) * chh, rad, color, ALPHA / 255f)
        }
        setCircles(listOf(mk(from, COLOR_FROM), mk(to, COLOR_TO)))
        var txt = m.substring(0, 2) + " ← " + m.substring(2, 4)
        if (m.length > 4) txt += "  ارتقا " + m.substring(4).uppercase()
        val b = accepted
        if (b != null && Math.abs(b[from]) == 6 && Math.abs((to % 8) - (from % 8)) == 2) txt += "  (قلعه)"
        txt += "\n" + r.score + "  عمق " + r.depth
        status(txt, 0xFF69F0AE.toInt())
    }

    // ---------------- shutdown ----------------
    private fun shutdown() {
        if (!started) {
            stopSelf()
            return
        }
        started = false
        running = false
        try {
            ch.removeCallbacksAndMessages(null)
        } catch (e: Exception) {
        }
        closeCalib()
        panel?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        circleView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        panel = null
        circleView = null
        try {
            vd?.release()
        } catch (e: Exception) {
        }
        try {
            reader?.close()
        } catch (e: Exception) {
        }
        try {
            projection?.stop()
        } catch (e: Exception) {
        }
        execEngine.execute { engine.destroy() }
        execEngine.shutdown()
        capThread?.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (started) shutdown()
        super.onDestroy()
    }
}
