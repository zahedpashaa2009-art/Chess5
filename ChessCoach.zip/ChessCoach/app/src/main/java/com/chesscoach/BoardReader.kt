package com.chesscoach

import java.nio.ByteBuffer

class Circle(val cx: Float, val cy: Float, val r: Float, val color: Int, val alpha: Float)

class Frame(
    private val buf: ByteBuffer,
    val w: Int,
    val h: Int,
    private val rowStride: Int,
    private val pixStride: Int
) {
    fun rgb(x: Int, y: Int): Int {
        val xx = if (x < 0) 0 else if (x >= w) w - 1 else x
        val yy = if (y < 0) 0 else if (y >= h) h - 1 else y
        val o = yy * rowStride + xx * pixStride
        val r = buf.get(o).toInt() and 0xFF
        val g = buf.get(o + 1).toInt() and 0xFF
        val b = buf.get(o + 2).toInt() and 0xFF
        return (r shl 16) or (g shl 8) or b
    }
}

class Templates(val shapes: Array<List<BooleanArray>>, val lumThr: Float)

class ParseResult(val board: IntArray, val uncertain: BooleanArray, val ok: Boolean)

/**
 * Board codes (index = rank*8 + file, rank 0 = chess rank 1):
 * 0 empty; white +1..+6, black -1..-6 for P N B R Q K.
 */
class BoardReader {
    companion object {
        const val G = 24
        const val N = G * G
        const val DIFF_T = 80

        private fun buildCorner(): IntArray {
            val ids = intArrayOf(0, 1, 2, G - 3, G - 2, G - 1)
            val out = IntArray(ids.size * ids.size)
            var k = 0
            for (j in ids) for (i in ids) {
                out[k++] = j * G + i
            }
            return out
        }

        val CORNER: IntArray = buildCorner()

        fun toSq(r: Int, c: Int, userWhite: Boolean): Int =
            if (userWhite) (7 - r) * 8 + c else r * 8 + (7 - c)

        fun screenRow(sq: Int, userWhite: Boolean): Int =
            if (userWhite) 7 - sq / 8 else sq / 8

        fun screenCol(sq: Int, userWhite: Boolean): Int =
            if (userWhite) sq % 8 else 7 - sq % 8

        // type index: P0 N1 B2 R3 Q4 K5
        private val BACK = intArrayOf(3, 1, 2, 4, 5, 2, 1, 3)

        fun initialBoard(): IntArray {
            val b = IntArray(64)
            for (f in 0..7) {
                b[f] = BACK[f] + 1
                b[8 + f] = 1
                b[48 + f] = -1
                b[56 + f] = -(BACK[f] + 1)
            }
            return b
        }

        fun encode(t: Templates): String {
            val sb = StringBuilder()
            sb.append(t.lumThr.toString()).append('|')
            for (k in 0..5) {
                for ((idx, m) in t.shapes[k].withIndex()) {
                    if (idx > 0) sb.append(',')
                    for (b in m) sb.append(if (b) '1' else '0')
                }
                if (k < 5) sb.append(';')
            }
            return sb.toString()
        }

        fun decode(s: String): Templates? {
            try {
                val parts = s.split('|')
                if (parts.size != 2) return null
                val thr = parts[0].toFloat()
                val types = parts[1].split(';')
                if (types.size != 6) return null
                val shapes = Array<List<BooleanArray>>(6) { k ->
                    types[k].split(',').filter { it.length == N }.map { str ->
                        BooleanArray(N) { idx -> str[idx] == '1' }
                    }
                }
                for (l in shapes) if (l.isEmpty()) return null
                return Templates(shapes, thr)
            } catch (e: Exception) {
                return null
            }
        }
    }

    private class Sq {
        val mask = BooleanArray(N)
        var occ = false
        var mass = 0
        var lum = 0f
    }

    // indexed by screen square r*8+c
    private val px = Array(64) { IntArray(N) }
    private val sqs = Array(64) { Sq() }
    private val hr = IntArray(256)
    private val hg = IntArray(256)
    private val hb = IntArray(256)

    private fun median(h: IntArray, n: Int): Int {
        var acc = 0
        for (i in 0..255) {
            acc += h[i]
            if (acc * 2 >= n) return i
        }
        return 255
    }

    /** 1 = white pieces at bottom, -1 = black at bottom, 0 = not a start-like position. */
    fun detectColor(): Int {
        var top = 0f
        var tn = 0
        var bot = 0f
        var bn = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                if (r in 2..5) {
                    if (s.occ) return 0
                } else if (s.occ) {
                    if (r <= 1) {
                        top += s.lum
                        tn++
                    } else {
                        bot += s.lum
                        bn++
                    }
                }
            }
        }
        if (tn < 14 || bn < 14) return 0
        val d = bot / bn - top / tn
        return if (d > 40f) 1 else if (d < -40f) -1 else 0
    }

    fun debug(): String {
        val sb = StringBuilder()
        var top = 0f
        var tn = 0
        var bot = 0f
        var bn = 0
        for (r in 0..7) {
            var cnt = 0
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                if (s.occ) {
                    cnt++
                    if (r <= 1) {
                        top += s.lum
                        tn++
                    } else if (r >= 6) {
                        bot += s.lum
                        bn++
                    }
                }
            }
            sb.append(cnt).append(' ')
        }
        sb.append(" | lum ")
        sb.append(if (tn > 0) (top / tn).toInt() else -1)
        sb.append("/")
        sb.append(if (bn > 0) (bot / bn).toInt() else -1)
        return sb.toString()
    }

    fun load(f: Frame, left: Float, top: Float, right: Float, bottom: Float, circles: List<Circle>) {
        val sw = (right - left) / 8f
        val sh = (bottom - top) / 8f
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val arr = px[r * 8 + c]
                val x0 = left + c * sw
                val y0 = top + r * sh
                for (j in 0 until G) {
                    val y = y0 + (j + 0.5f) / G * sh
                    val yi = y.toInt()
                    for (i in 0 until G) {
                        val x = x0 + (i + 0.5f) / G * sw
                        var v = f.rgb(x.toInt(), yi)
                        if (circles.isNotEmpty()) v = unblend(v, x, y, circles)
                        arr[j * G + i] = v
                    }
                }
                analyze(arr, sqs[r * 8 + c])
            }
        }
    }

    private fun clamp(v: Float): Int {
        val i = Math.round(v)
        return if (i < 0) 0 else if (i > 255) 255 else i
    }

    private fun unblend(v: Int, x: Float, y: Float, circles: List<Circle>): Int {
        for (c in circles) {
            val dx = x - c.cx
            val dy = y - c.cy
            val d = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (d <= c.r - 1.5f) {
                val a = c.alpha
                val cr = (c.color shr 16) and 255
                val cg = (c.color shr 8) and 255
                val cb = c.color and 255
                val r = clamp((((v shr 16) and 255) - cr * a) / (1f - a))
                val g = clamp((((v shr 8) and 255) - cg * a) / (1f - a))
                val b = clamp(((v and 255) - cb * a) / (1f - a))
                return (r shl 16) or (g shl 8) or b
            } else if (d <= c.r + 1.5f) {
                return -1
            }
        }
        return v
    }

    private fun analyze(arr: IntArray, s: Sq) {
        java.util.Arrays.fill(s.mask, false)
        s.occ = false
        s.mass = 0
        s.lum = 0f
        java.util.Arrays.fill(hr, 0)
        java.util.Arrays.fill(hg, 0)
        java.util.Arrays.fill(hb, 0)
        var n = 0
        for (k in 0 until N) {
            val v = arr[k]
            if (v < 0) continue
            hr[(v shr 16) and 255]++
            hg[(v shr 8) and 255]++
            hb[v and 255]++
            n++
        }
        if (n < 100) return
        val br = median(hr, n)
        val bg = median(hg, n)
        val bb = median(hb, n)
        val sb0 = (br + bg + bb + 1).toFloat()
        val nr = br / sb0
        val ng = bg / sb0
        val nb = bb / sb0
        for (k in 0 until N) {
            val v = arr[k]
            if (v < 0) continue
            val r = (v shr 16) and 255
            val g = (v shr 8) and 255
            val b = v and 255
            val d = Math.abs(r - br) + Math.abs(g - bg) + Math.abs(b - bb)
            if (d > 40) {
                // wood shadows/highlights keep the wood's colour ratio; pieces (grey) do not
                val sp = (r + g + b + 1).toFloat()
                val chroma = Math.abs(r / sp - nr) + Math.abs(g / sp - ng) + Math.abs(b / sp - nb)
                if (chroma > 0.08f) {
                    val ci = k % G
                    val cj = k / G
                    if (ci >= 2 && ci < G - 2 && cj >= 2 && cj < G - 2) s.mask[k] = true
                }
            }
        }
        fillGaps(s.mask)
        val mass = keepLargest(s.mask)
        s.mass = mass
        s.occ = mass >= 60
        java.util.Arrays.fill(hl, 0)
        var cnt = 0
        for (k in 0 until N) {
            if (!s.mask[k]) continue
            val v = arr[k]
            val r = (v shr 16) and 255
            val g = (v shr 8) and 255
            val b = v and 255
            hl[(r * 299 + g * 587 + b * 114) / 1000]++
            cnt++
        }
        // median luminance of the piece pixels (robust against stray wood pixels)
        var lm = 0
        if (cnt > 0) {
            var acc = 0
            for (i in 0..255) {
                acc += hl[i]
                if (acc * 2 >= cnt) {
                    lm = i
                    break
                }
            }
        }
        s.lum = lm.toFloat()
    }

    private val hl = IntArray(256)
    private val lab = IntArray(N)
    private val stack = IntArray(N)

    /** Keeps only the biggest connected blob (the piece); removes wood-grain noise. */
    private fun keepLargest(m: BooleanArray): Int {
        java.util.Arrays.fill(lab, 0)
        var best = 0
        var bestId = 0
        var id = 0
        for (s0 in 0 until N) {
            if (!m[s0] || lab[s0] != 0) continue
            id++
            var sp = 0
            stack[sp++] = s0
            lab[s0] = id
            var size = 0
            while (sp > 0) {
                val p = stack[--sp]
                size++
                val x = p % G
                val y = p / G
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val nx = x + dx
                        val ny = y + dy
                        if (nx < 0 || ny < 0 || nx >= G || ny >= G) continue
                        val q = ny * G + nx
                        if (m[q] && lab[q] == 0) {
                            lab[q] = id
                            stack[sp++] = q
                        }
                    }
                }
            }
            if (size > best) {
                best = size
                bestId = id
            }
        }
        for (k in 0 until N) if (m[k] && lab[k] != bestId) m[k] = false
        return best
    }

    fun occAt(r: Int, c: Int): Boolean = sqs[r * 8 + c].occ
    fun massAt(r: Int, c: Int): Int = sqs[r * 8 + c].mass
    fun maskAt(r: Int, c: Int): BooleanArray = sqs[r * 8 + c].mask

    private fun fillGaps(m: BooleanArray) {
        for (j in 0 until G) {
            var last = -1
            for (i in 0 until G) {
                if (m[j * G + i]) {
                    val gap = i - last - 1
                    if (last >= 0 && gap in 1..3) {
                        for (k in last + 1 until i) m[j * G + k] = true
                    }
                    last = i
                }
            }
        }
    }

    private fun shapeDist(a: BooleanArray, b: BooleanArray): Int {
        var best = Int.MAX_VALUE
        for (dy in -1..1) {
            for (dx in -1..1) {
                var d = 0
                for (y in 0 until G) {
                    val yy = y + dy
                    for (x in 0 until G) {
                        val xx = x + dx
                        val av = a[y * G + x]
                        val bv = if (xx in 0 until G && yy in 0 until G) b[yy * G + xx] else false
                        if (av != bv) d++
                    }
                }
                if (d < best) best = d
            }
        }
        return best
    }

    fun parse(userWhite: Boolean, tpl: Templates, prev: IntArray?): ParseResult {
        val board = IntArray(64)
        val unc = BooleanArray(64)
        var ok = true
        for (r in 0..7) {
            for (c in 0..7) {
                val s = sqs[r * 8 + c]
                val sq = toSq(r, c, userWhite)
                if (!s.occ) {
                    board[sq] = 0
                    continue
                }
                var best = Int.MAX_VALUE
                var bt = 0
                for (t in 0..5) {
                    for (tm in tpl.shapes[t]) {
                        val d = shapeDist(s.mask, tm)
                        if (d < best) {
                            best = d
                            bt = t
                        }
                    }
                }
                val white = s.lum > tpl.lumThr
                val code = (bt + 1) * (if (white) 1 else -1)
                if (best <= 0.22f * s.mass) {
                    board[sq] = code
                } else {
                    val p = if (prev != null) prev[sq] else 0
                    if (p != 0) {
                        board[sq] = p
                        unc[sq] = true
                    } else if (best <= 0.5f * s.mass) {
                        board[sq] = code
                        unc[sq] = true
                    } else {
                        board[sq] = code
                        ok = false
                    }
                }
            }
        }
        return ParseResult(board, unc, ok)
    }

    /** Learn piece shapes from the standard starting position currently on screen. */
    fun learn(userWhite: Boolean): Templates? {
        val lists = Array(6) { ArrayList<BooleanArray>() }
        var wl = 0f
        var wn = 0
        var bl = 0f
        var bn = 0
        val init = initialBoard()
        for (r in 0..7) {
            for (c in 0..7) {
                val sq = toSq(r, c, userWhite)
                val s = sqs[r * 8 + c]
                val expected = init[sq]
                if (expected == 0) {
                    if (s.occ) return null
                } else {
                    if (!s.occ) return null
                    lists[Math.abs(expected) - 1].add(s.mask.copyOf())
                    if (expected > 0) {
                        wl += s.lum
                        wn++
                    } else {
                        bl += s.lum
                        bn++
                    }
                }
            }
        }
        if (wn == 0 || bn == 0) return null
        val wm = wl / wn
        val bm = bl / bn
        if (wm - bm < 50f) return null
        val shapes = Array<List<BooleanArray>>(6) { k -> pick(lists[k], 4) }
        return Templates(shapes, (wm + bm) / 2f)
    }

    private fun pick(l: List<BooleanArray>, n: Int): List<BooleanArray> {
        if (l.size <= n) return ArrayList(l)
        val out = ArrayList<BooleanArray>()
        for (k in 0 until n) out.add(l[k * l.size / n])
        return out
    }
}
