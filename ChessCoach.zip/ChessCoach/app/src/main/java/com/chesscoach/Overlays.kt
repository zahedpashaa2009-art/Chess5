package com.chesscoach

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout

/** Draws the solid circles. Coordinates are real screen pixels. */
class CircleView(ctx: Context) : View(ctx) {
    @Volatile
    var circles: List<Circle> = emptyList()
    private val loc = IntArray(2)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        for (ci in circles) {
            p.color = Color.argb(
                Math.round(ci.alpha * 255f),
                (ci.color shr 16) and 255,
                (ci.color shr 8) and 255,
                ci.color and 255
            )
            c.drawCircle(ci.cx - loc[0], ci.cy - loc[1], ci.r, p)
        }
    }
}

/** Full-screen board calibration: drag corners / move the grid, nudge with buttons. */
class CalibLayout(ctx: Context, r: RectF, private val onDone: (RectF) -> Unit) : FrameLayout(ctx) {
    private val rect = RectF(r)
    private val grid = GridView(ctx)

    inner class GridView(c: Context) : View(c) {
        private val loc = IntArray(2)
        private val pGrid = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pRect = Paint(Paint.ANTI_ALIAS_FLAG)
        private val pHandle = Paint(Paint.ANTI_ALIAS_FLAG)
        private var drag = -1
        private var lx = 0f
        private var ly = 0f

        init {
            pGrid.color = 0xAAFFEB3B.toInt()
            pGrid.strokeWidth = 2f
            pRect.color = 0xFFFF1744.toInt()
            pRect.strokeWidth = 4f
            pRect.style = Paint.Style.STROKE
            pHandle.color = 0xCCFF1744.toInt()
        }

        private fun cx(k: Int): Float = if (k == 0 || k == 3) rect.left else rect.right
        private fun cy(k: Int): Float = if (k == 0 || k == 1) rect.top else rect.bottom

        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            val w = (rect.right - rect.left) / 8f
            val h = (rect.bottom - rect.top) / 8f
            for (i in 0..8) {
                c.drawLine(rect.left + i * w, rect.top, rect.left + i * w, rect.bottom, pGrid)
                c.drawLine(rect.left, rect.top + i * h, rect.right, rect.top + i * h, pGrid)
            }
            c.drawRect(rect, pRect)
            for (k in 0..3) c.drawCircle(cx(k), cy(k), 26f, pHandle)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val x = e.rawX
            val y = e.rawY
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    drag = -1
                    for (k in 0..3) {
                        val dx = x - cx(k)
                        val dy = y - cy(k)
                        if (dx * dx + dy * dy < 80f * 80f) {
                            drag = k
                            break
                        }
                    }
                    if (drag < 0 && rect.contains(x, y)) drag = 4
                    lx = x
                    ly = y
                }
                MotionEvent.ACTION_MOVE -> {
                    if (drag >= 0) {
                        val dx = x - lx
                        val dy = y - ly
                        when (drag) {
                            0 -> { rect.left += dx; rect.top += dy }
                            1 -> { rect.right += dx; rect.top += dy }
                            2 -> { rect.right += dx; rect.bottom += dy }
                            3 -> { rect.left += dx; rect.bottom += dy }
                            else -> rect.offset(dx, dy)
                        }
                        lx = x
                        ly = y
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag = -1
            }
            return true
        }
    }

    init {
        addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        fun b(t: String, a: () -> Unit) {
            val btn = Button(ctx)
            btn.text = t
            btn.isAllCaps = false
            btn.minWidth = 0
            btn.minimumWidth = 0
            btn.setOnClickListener {
                a()
                grid.invalidate()
            }
            row.addView(btn)
        }
        b("◀") { rect.offset(-2f, 0f) }
        b("▶") { rect.offset(2f, 0f) }
        b("▲") { rect.offset(0f, -2f) }
        b("▼") { rect.offset(0f, 2f) }
        b("+") { rect.inset(-2f, -2f) }
        b("−") { rect.inset(2f, 2f) }
        b("تایید") { onDone(RectF(rect)) }
        val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = (110 * ctx.resources.displayMetrics.density).toInt()
        addView(row, lp)
    }
}
